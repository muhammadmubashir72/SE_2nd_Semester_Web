﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project
{
    public partial class form2 : Form
    {
        public form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Signup_btn_Click(object sender, EventArgs e)
        {
            if (F_nametxt.Text != "" && L_nametxt.Text != "" && Dob_txt.Text !="" && C_passwordtxt.Text !="" && C_emailtxt.Text !="")
            {
                string f_name = F_nametxt.Text;
                string l_name = L_nametxt.Text;
                string dob = Dob_txt.Text;
                string cpasword = C_passwordtxt.Text;
                string cemail = C_emailtxt.Text;
                succlbl.Visible = true;
                clickherelbl.Visible = true;
            }
            else
            {
                MessageBox.Show("please enter complete info");
            }
        }

        private void clickherelbl_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }   
    }
}
