﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace project
{
    public partial class Form4 : Form
    {
        string dbconnection = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\AY\Desktop\project\project\project\Database1.mdf;Integrated Security = True";
        public Form4()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {


        }

        private void okbtn_Click(object sender, EventArgs e)
        {
            if (p_nametxt.Text != "" && p_phonetxt.Text != "" && comboBox1.Text != "" && dateTimePicker1.Text != "")
            {

                string pname = p_nametxt.Text;
                string phone = p_phonetxt.Text;
                string select_seat = comboBox1.Text;
                string select_date = dateTimePicker1.Text;


                SqlConnection con = new SqlConnection(dbconnection);
                string query = "insert into bpuserinfo(pname,phone,combbox1,datetimepiker1) values('" + p_nametxt.Text + "','" + p_phonetxt.Text + "','" + comboBox1.Text + "','" + dateTimePicker1.Text + "')";

                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Your Seat is Booked");
                    con.Close();
                }
                catch
                {
                    MessageBox.Show(query, ToString());
                }
            }
            else
            {
                MessageBox.Show("please enter complete info");
            }
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
    }
}

