﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace project
{
    public partial class Form1 : Form
    {
        string dbconnection = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\AY\Desktop\project\project\project\Database1.mdf;Integrated Security = True";
        public static Form1 instance;
        public Form1()
        {
            InitializeComponent();
            instance = this;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (nametxt.Text != "" && emailtxt.Text != "" && paswordtxt.Text != "")
            {
                string name = nametxt.Text;
                string email = emailtxt.Text;
                string password = paswordtxt.Text;

                SqlConnection conn = new SqlConnection(dbconnection);
                string query = "Select password from userinfo where email='" + emailtxt.Text + "'";

                SqlCommand cmd = new SqlCommand(query, conn);

                try
                {
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        password = reader["password"].ToString();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());

                }
                if (password == paswordtxt.Text)
                {
                    MessageBox.Show("login Succesful");
                    this.Hide();
                    Form4 f = new Form4();
                    f.Show();
                    
                        


                }
                else
                {
                    MessageBox.Show("login Unsucesful");
                }

            }
            else
                MessageBox.Show("please enter complete login info");
        }

        private void label4_Click(object sender, EventArgs e)
        {
            form2 f = new form2();
            f.Show();
            this.Hide();    

        }

        private void nametxt_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
