﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace project
{
    public partial class form2 : Form

    {
        string dbconnection = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\AY\Desktop\project\project\project\Database1.mdf;Integrated Security = True";                          
        public form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Signup_btn_Click(object sender, EventArgs e)
        {
            if (Nametxt.Text != "" && Dob_txt.Text !="" && C_passwordtxt.Text !="" && C_emailtxt.Text !="")
            {
                
                string name = Nametxt.Text;
                string dob = Dob_txt.Text;
                string cpasword = C_passwordtxt.Text;
                string cemail = C_emailtxt.Text;
                succlbl.Visible = true;
                clickherelbl.Visible = true;

                SqlConnection con = new SqlConnection(dbconnection);
                string query = "insert into userinfo(name,dob,email,password) values('"+Nametxt.Text+"','"+Dob_txt.Text+"','"+C_emailtxt.Text+"','"+C_passwordtxt.Text+"')";

                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Succesful");
                    con.Close();
                }
                catch
                {
                    MessageBox.Show(query,ToString());
                }
            }
            else
            {
                MessageBox.Show("please enter complete info");
            }
        }

        private void clickherelbl_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }
    }
}
