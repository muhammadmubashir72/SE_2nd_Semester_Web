﻿
namespace project
{
    partial class form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form2));
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Signup_btn = new System.Windows.Forms.Button();
            this.Nametxt = new System.Windows.Forms.TextBox();
            this.Dob_txt = new System.Windows.Forms.TextBox();
            this.C_emailtxt = new System.Windows.Forms.TextBox();
            this.C_passwordtxt = new System.Windows.Forms.TextBox();
            this.succlbl = new System.Windows.Forms.Label();
            this.clickherelbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(480, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 23);
            this.label2.TabIndex = 0;
            this.label2.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(480, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 23);
            this.label3.TabIndex = 0;
            this.label3.Text = "Date Of Birth";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(480, 184);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 23);
            this.label4.TabIndex = 0;
            this.label4.Text = "Email";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(480, 227);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(123, 23);
            this.label6.TabIndex = 0;
            this.label6.Text = "Set Password";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // Signup_btn
            // 
            this.Signup_btn.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.Signup_btn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Signup_btn.Location = new System.Drawing.Point(712, 273);
            this.Signup_btn.Name = "Signup_btn";
            this.Signup_btn.Size = new System.Drawing.Size(111, 37);
            this.Signup_btn.TabIndex = 1;
            this.Signup_btn.Text = "Sign Up";
            this.Signup_btn.UseVisualStyleBackColor = false;
            this.Signup_btn.Click += new System.EventHandler(this.Signup_btn_Click);
            // 
            // Nametxt
            // 
            this.Nametxt.Location = new System.Drawing.Point(652, 96);
            this.Nametxt.Name = "Nametxt";
            this.Nametxt.Size = new System.Drawing.Size(213, 22);
            this.Nametxt.TabIndex = 2;
            this.Nametxt.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // Dob_txt
            // 
            this.Dob_txt.Location = new System.Drawing.Point(652, 142);
            this.Dob_txt.Name = "Dob_txt";
            this.Dob_txt.Size = new System.Drawing.Size(213, 22);
            this.Dob_txt.TabIndex = 2;
            this.Dob_txt.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // C_emailtxt
            // 
            this.C_emailtxt.Location = new System.Drawing.Point(652, 186);
            this.C_emailtxt.Name = "C_emailtxt";
            this.C_emailtxt.Size = new System.Drawing.Size(213, 22);
            this.C_emailtxt.TabIndex = 2;
            this.C_emailtxt.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // C_passwordtxt
            // 
            this.C_passwordtxt.Location = new System.Drawing.Point(652, 228);
            this.C_passwordtxt.Name = "C_passwordtxt";
            this.C_passwordtxt.Size = new System.Drawing.Size(213, 22);
            this.C_passwordtxt.TabIndex = 2;
            // 
            // succlbl
            // 
            this.succlbl.AutoSize = true;
            this.succlbl.BackColor = System.Drawing.Color.Transparent;
            this.succlbl.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.succlbl.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.succlbl.Location = new System.Drawing.Point(547, 370);
            this.succlbl.Name = "succlbl";
            this.succlbl.Size = new System.Drawing.Size(276, 32);
            this.succlbl.TabIndex = 3;
            this.succlbl.Text = "Sign Up is Successfull";
            this.succlbl.Visible = false;
            // 
            // clickherelbl
            // 
            this.clickherelbl.AutoSize = true;
            this.clickherelbl.BackColor = System.Drawing.Color.Transparent;
            this.clickherelbl.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clickherelbl.ForeColor = System.Drawing.Color.DarkBlue;
            this.clickherelbl.Location = new System.Drawing.Point(720, 410);
            this.clickherelbl.Name = "clickherelbl";
            this.clickherelbl.Size = new System.Drawing.Size(107, 19);
            this.clickherelbl.TabIndex = 4;
            this.clickherelbl.Text = "Click Here....";
            this.clickherelbl.Visible = false;
            this.clickherelbl.Click += new System.EventHandler(this.clickherelbl_Click);
            // 
            // form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(879, 465);
            this.Controls.Add(this.clickherelbl);
            this.Controls.Add(this.succlbl);
            this.Controls.Add(this.C_passwordtxt);
            this.Controls.Add(this.C_emailtxt);
            this.Controls.Add(this.Dob_txt);
            this.Controls.Add(this.Nametxt);
            this.Controls.Add(this.Signup_btn);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sign Up";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Signup_btn;
        private System.Windows.Forms.TextBox Nametxt;
        private System.Windows.Forms.TextBox Dob_txt;
        private System.Windows.Forms.TextBox C_emailtxt;
        private System.Windows.Forms.TextBox C_passwordtxt;
        private System.Windows.Forms.Label succlbl;
        private System.Windows.Forms.Label clickherelbl;
    }
}