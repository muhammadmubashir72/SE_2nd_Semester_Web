use project

--------------------------------------------
--SELECT ALL THE TABLES
--------------------------------------------
select * from Patient
select * from Hospital
select * from Wards
select * from Doctors
select * from Shifts

--------------------------------------------
--DROP SEQUENCE
--------------------------------------------

drop table Shifts
drop table Hospital
drop table Patient
drop table Wards
drop table Doctors



----------------------------------------------
--INSERTION
----------------------------------------------

--- INSERT INTO PATIENT----------
Insert into Patient values('AYESHA','Karachi','03871882','FEMALE',30,430215367092881,'Critical','ALIVE','SINDH',1001);
Insert into Patient values('AKMAL','LAHORE','078771328','MALE',40,430215738652885,'STABLE','DEAD','PUNJAB',1003);
Insert into Patient values('HAIDER','PESHAWAR','0612672189','MALE',50,430215367099876,'CRITICAL','ALIVE','KPK',1004);
Insert into Patient values('JOHN','ISLAMABAD','012871279','MALE',60,430215367092542,'Critical','DEAD','ISLAMABAD',1005);
Insert into Patient values('JAVIER','PESHAWAR','0891726912','MALE',25,430215367092098,'Critical','ALIVE','KPK',1004);
Insert into Patient values('laiba','Lahore','0312763713','FEMALE',21,430215367092121,'STABLE','RECOVERED','Punjab',1003);



----- INSERT INTO DOCTORS------------------
INSERT INTO Doctors values(101,'Dr.Tanveer','0384918293')
INSERT INTO Doctors values(102,'Dr.Yousaf','0642423637')
INSERT INTO Doctors values(103,'Dr.saif','0742363654')
INSERT INTO Doctors values(104,'Dr.Mujahid','037546352')
INSERT INTO Doctors values(105,'Dr.Zain','036347424')
INSERT INTO Doctors values(106,'Dr.Tousef','035635623')
INSERT INTO Doctors values(107,'Dr.Abdullah','062452242')




--- INSERT INTO HOSPITALS

INSERT INTO Hospital values(201,'Jinnah Hospital',4,'Karachi')
INSERT INTO Hospital values(202,'National Medical',7,'Karachi')
INSERT INTO Hospital values(203,'Liaquat National',8,'Lahore')
INSERT INTO Hospital values(204,'PNS Shifa',6,'Peshawar')
INSERT INTO Hospital values(205,'Agha khan Hospital',10,'Islamabad')



---INSERT INTO WARDS
INSERT INTO Wards values(1001,1150,1500,201)
INSERT INTO Wards values(1002,3250,4000,202)
INSERT INTO Wards values(1003,500,3500,203)
INSERT INTO Wards values(1004,1500,5500,204)
INSERT INTO Wards values(1005,2500,6000,205)

---INSERT INTO SHIFTS

INSERT INTO Shifts values(1002,107,'8AM-6PM')
INSERT INTO Shifts values(1001,102,'10AM-12PM')
INSERT INTO Shifts values(1005,103,'12PM-6AM')
INSERT INTO Shifts values(1003,104,'9AM-6PM')
INSERT INTO Shifts values(1004,101,'1AM-10AM')


--------------------------------------------
--PROCEDURES
--------------------------------------------

--ADD THE PATIENT USING THE PROCEDURE
drop procedure Add_patient
create procedure Add_patient(@P_Name nvarchar(50),@P_Address nvarchar(50),@Contact nvarchar(50),@P_Gender nvarchar(50),@P_Age int,@P_CNIC nvarchar(50),@P_Condition nvarchar(50),@P_Status nvarchar(50),@P_Province nvarchar(50),@Ward_ID int)
as
begin
insert into Patient values(@P_Name,@P_Address,@Contact,@P_Gender,@P_Age,@P_CNIC,@P_Condition,@P_Status,@P_Province,@Ward_ID)
end

exec Add_patient 'Haris','Karachi','3265897','Other',32,'123456789012345','Stable','Alive','KPK',,101

--UPDATE THE PATIENT STATUS_INFO (VIEW) USING THE PROCEDURE
create procedure Update_Patient(@id int,@Condition nvarchar(50),@Status nvarchar(50))
As
begin
declare @C_Status nvarchar(50)=(select P_Status from patient where P_ID=@id)
declare @C_Condition nvarchar(50)=(select P_Condition from patient where P_ID=@id)

if(@Condition='Empty')
	begin
		update STATUS_INFO set P_Condition= @C_Condition ,P_Status=@Status where P_ID=@id
	end
else if (@Status='Empty')
	begin
		update STATUS_INFO set P_Condition= @Condition ,P_Status=@C_Status where P_ID=@id
	end
else if (@Condition='Empty' and @Status='Empty')
	begin
		update STATUS_INFO set P_Condition= @C_Condition ,P_Status=@C_Status where P_ID=@id
	end
else
	begin
		update STATUS_INFO set P_Condition= @Condition ,P_Status=@Status where P_ID=@id
	end
end

exec Update_Patient 2,'Stable','Recovered'
select * from STATUS_INFO




drop procedure Update_Patient
-------------------------------


--------------------------------------------
--FUNCTIONS
--------------------------------------------


--CHECK STATUS CREDIBILITY
CREATE FUNCTION CHECK_STATUS(@id int,@Updated_Status nvarchar(50))
returns nvarchar(50)
As
begin
	declare @C_Status nvarchar(50)=(select P_Status from patient where P_Id=@id);
	if(@Updated_Status='Alive' and @C_Status='DEAD')
	begin
		return 'F'
	end
	else
	begin
		return 'T'
	end
	return '0'
end

select dbo.CHECK_STATUS (2,'ALiVe')

select * from patient
drop function dbo.CHECK_STATUS


--------------------------------------------
--VIEWS
--------------------------------------------

-- when user update the status of patient 

CREATE VIEW STATUS_INFO AS
select P_ID,P_Name,P_Condition,P_Status from patient

select * from STATUS_INFO

-- when user try to delete 
CREATE VIEW P_INFO 
AS
select P_ID,P_Name,P_AGE,P_Condition,P_Status,P_Province from patient





---for Alive patient View
Create view Alive As
select p_name,P_age,P_Province from patient where P_Status='Alive' group by P_name,P_age,P_Province


select count(*) as [Alive Patient] from Alive


-- For Recoverd
Create view Recovered As
select  p_name,P_age,P_Province from patient where P_Status='Recovered' group by P_name,P_age,P_Province

select Count(*) as [Recovered Patient]from Recovered

-- For Dead Patient View
Create view Dead As
select  p_name,P_age,P_Province from patient where P_Status='Dead' group by P_name,P_age,P_Province

select count(*) from  Dead where P_Province='Punjab'

-- For Critical Patient
Create view Critical_Patient As

select p_name,P_age,P_Province from patient where P_Condition='Critical' group by P_name,P_age,P_Province

select count(*) as [Critical Patient]from Critical_Patient

-- History VIEW
CREATE View Show_History AS

select Name,Age,Contact,Status,province,Delete_Date,Update_Date,Admit_Date from Replica_Data

drop view Show_History

select * from Show_History






--------------------------------



-----------TRRIGER------------------------

create table Replica_data(
	ID int,
	Name nvarchar(50),
	Address nvarchar(50),
	Contact nvarchar(50),
	Gender nvarchar(50),
	Age int,
	CNIC nvarchar(50),
	Condition nvarchar(50),
	Status nvarchar(50),
	Province nvarchar(50),
	Ward_ID int ,
	Delete_Date date,
	Update_Date date,
	Admit_Date date
)
Drop table Replica_data


Create Trigger History on Patient
after delete,Update,insert
as
begin
if exists(Select* from inserted) and exists(select * from deleted)
		begin
		insert into Replica_data 
			select * ,null,GETDATE(),null from deleted
		end
else if exists(Select* from inserted)
			begin
				insert into Replica_data 
				select *,null,null,GETDATE() from inserted
			end
	
else if exists(Select * from deleted) and not exists (select * from inserted)
	begin
		insert into Replica_data
		select * ,GETDATE(),null,null from deleted
	end
end

drop trigger History
-----
