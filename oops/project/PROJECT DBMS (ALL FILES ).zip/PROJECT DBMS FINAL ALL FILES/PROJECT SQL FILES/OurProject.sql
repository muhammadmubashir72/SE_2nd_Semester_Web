create database Project
use Project
select * from Patient
select * from Hospital
select * from Wards
select * from Shifts
select * from Doctors
select * from users


create table Patient(
	P_ID int PRIMARY KEY IDENTITY(1,1) NOT NULL,
	P_Name nvarchar(50) NOT NULL,
	P_Address nvarchar(50),
	P_Contact nvarchar(50),
	P_Gender nvarchar(50),
	P_Age int not null,
	P_CNIC nvarchar(50) check(P_CNIC between 100000000000000 and 999999999999999),
	P_Condition nvarchar(50),
	P_Status nvarchar(50),
	P_Province nvarchar(50),
	Ward_ID int foreign key references WARDS(W_ID)
)
drop table Patient

create table users(
	U_name nvarchar(50) not null,
	U_email nvarchar(50) not null,
	U_Password nvarchar(50) not null,
	U_Role nvarchar(50)
	)

create table Hospital(
	H_ID int PRIMARY KEY,
	H_Name nvarchar(50),
	H_No_Wards int,
	H_Address nvarchar(50)
)

create table Wards(
	W_ID int PRIMARY KEY,
	W_No_Patients int,
	W_Capacity int,
	H_ID int foreign key references Hospital(H_ID)
)

create table Doctors(
	D_ID int PRIMARY KEY,
	D_Name nvarchar(50) not null,
	D_Contact nvarchar(50),
)
drop table Doctors

create table Shifts(
	Ward_ID int Foreign key references WARDS(W_ID),
	Doc_ID int Foreign key references DOCTORS(D_ID),
	S_Timings nvarchar(50),
)


-------------------------USER AND ROLE-------------------------

CREATE LOGIN COVID_TRACKER
WITH PASSWORD='xyz123';
CREATE USER ADMIN_
FOR LOGIN COVID_TRACKER

