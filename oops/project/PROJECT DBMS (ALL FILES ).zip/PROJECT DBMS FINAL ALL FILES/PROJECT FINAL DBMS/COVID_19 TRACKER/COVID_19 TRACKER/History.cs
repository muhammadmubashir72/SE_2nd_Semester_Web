﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace COVID_19_TRACKER
{
    public partial class History : Form
    {
        public History()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Project;Integrated Security=True");
        private void History_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projectDataSet7.Show_History' table. You can move, or remove it, as needed.
            this.show_HistoryTableAdapter2.Fill(this.projectDataSet7.Show_History);
            // TODO: This line of code loads data into the 'projectDataSet6.Show_History' table. You can move, or remove it, as needed.
            this.show_HistoryTableAdapter1.Fill(this.projectDataSet6.Show_History);
            // TODO: This line of code loads data into the 'projectDataSet4.Show_History' table. You can move, or remove it, as needed.
            this.show_HistoryTableAdapter.Fill(this.projectDataSet4.Show_History);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home H = new Home();
            H.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
