﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace COVID_19_TRACKER
{
    public partial class Delete_Patient : Form
    {
        public Delete_Patient()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projectDataSet3.P_INFO' table. You can move, or remove it, as needed.
            this.p_INFOTableAdapter2.Fill(this.projectDataSet3.P_INFO);
            // TODO: This line of code loads data into the 'projectDataSet2.P_INFO' table. You can move, or remove it, as needed.
            this.p_INFOTableAdapter1.Fill(this.projectDataSet2.P_INFO);
            // TODO: This line of code loads data into the 'projectDataSet1.P_INFO' table. You can move, or remove it, as needed.
            this.p_INFOTableAdapter.Fill(this.projectDataSet1.P_INFO);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Project;Integrated Security=True");
            con.Open();
            SqlCommand Query = new SqlCommand("Delete from P_INFO where P_ID = "+textBox1.Text,con);
            var i=Query.ExecuteNonQuery();
            if (i == 1)
            {
                MessageBox.Show("Error");
            }
            else
            {
                MessageBox.Show("RECORD DELETED..");
            }
            DataTable tab = new DataTable();
            SqlCommand Q = new SqlCommand("select * from P_INFO", con);
            SqlDataAdapter tab1 = new SqlDataAdapter(Q);
            tab1.Fill(tab);
            dataGridView1.DataSource = tab;
            textBox1.Text = "";
            con.Close();
            this.p_INFOTableAdapter2.Fill(this.projectDataSet3.P_INFO);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home h = new Home();
            h.ShowDialog();
        }
    }
}
