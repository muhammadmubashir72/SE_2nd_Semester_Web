﻿namespace COVID_19_TRACKER
{
    partial class Delete_Patient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.projectDataSet1 = new COVID_19_TRACKER.ProjectDataSet1();
            this.pINFOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.p_INFOTableAdapter = new COVID_19_TRACKER.ProjectDataSet1TableAdapters.P_INFOTableAdapter();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.projectDataSet2 = new COVID_19_TRACKER.ProjectDataSet2();
            this.pINFOBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.p_INFOTableAdapter1 = new COVID_19_TRACKER.ProjectDataSet2TableAdapters.P_INFOTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.pIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pAGEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pConditionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pStatusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pProvinceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wardIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.projectDataSet3 = new COVID_19_TRACKER.ProjectDataSet3();
            this.pINFOBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.p_INFOTableAdapter2 = new COVID_19_TRACKER.ProjectDataSet3TableAdapters.P_INFOTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pINFOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pINFOBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pINFOBindingSource2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(271, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(331, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "DELETE PATIENT";
            // 
            // projectDataSet1
            // 
            this.projectDataSet1.DataSetName = "ProjectDataSet1";
            this.projectDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pINFOBindingSource
            // 
            this.pINFOBindingSource.DataMember = "P_INFO";
            this.pINFOBindingSource.DataSource = this.projectDataSet1;
            // 
            // p_INFOTableAdapter
            // 
            this.p_INFOTableAdapter.ClearBeforeFill = true;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(344, 251);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(110, 24);
            this.textBox1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(263, 253);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "P_ID";
            // 
            // projectDataSet2
            // 
            this.projectDataSet2.DataSetName = "ProjectDataSet2";
            this.projectDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pINFOBindingSource1
            // 
            this.pINFOBindingSource1.DataMember = "P_INFO";
            this.pINFOBindingSource1.DataSource = this.projectDataSet2;
            // 
            // p_INFOTableAdapter1
            // 
            this.p_INFOTableAdapter1.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.pIDDataGridViewTextBoxColumn,
            this.pNameDataGridViewTextBoxColumn,
            this.pAGEDataGridViewTextBoxColumn,
            this.pConditionDataGridViewTextBoxColumn,
            this.pStatusDataGridViewTextBoxColumn,
            this.pProvinceDataGridViewTextBoxColumn,
            this.wardIDDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.pINFOBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(12, 98);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(745, 127);
            this.dataGridView1.TabIndex = 4;
            // 
            // pIDDataGridViewTextBoxColumn
            // 
            this.pIDDataGridViewTextBoxColumn.DataPropertyName = "P_ID";
            this.pIDDataGridViewTextBoxColumn.HeaderText = "P_ID";
            this.pIDDataGridViewTextBoxColumn.Name = "pIDDataGridViewTextBoxColumn";
            this.pIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pNameDataGridViewTextBoxColumn
            // 
            this.pNameDataGridViewTextBoxColumn.DataPropertyName = "P_Name";
            this.pNameDataGridViewTextBoxColumn.HeaderText = "P_Name";
            this.pNameDataGridViewTextBoxColumn.Name = "pNameDataGridViewTextBoxColumn";
            // 
            // pAGEDataGridViewTextBoxColumn
            // 
            this.pAGEDataGridViewTextBoxColumn.DataPropertyName = "P_AGE";
            this.pAGEDataGridViewTextBoxColumn.HeaderText = "P_AGE";
            this.pAGEDataGridViewTextBoxColumn.Name = "pAGEDataGridViewTextBoxColumn";
            // 
            // pConditionDataGridViewTextBoxColumn
            // 
            this.pConditionDataGridViewTextBoxColumn.DataPropertyName = "P_Condition";
            this.pConditionDataGridViewTextBoxColumn.HeaderText = "P_Condition";
            this.pConditionDataGridViewTextBoxColumn.Name = "pConditionDataGridViewTextBoxColumn";
            // 
            // pStatusDataGridViewTextBoxColumn
            // 
            this.pStatusDataGridViewTextBoxColumn.DataPropertyName = "P_Status";
            this.pStatusDataGridViewTextBoxColumn.HeaderText = "P_Status";
            this.pStatusDataGridViewTextBoxColumn.Name = "pStatusDataGridViewTextBoxColumn";
            // 
            // pProvinceDataGridViewTextBoxColumn
            // 
            this.pProvinceDataGridViewTextBoxColumn.DataPropertyName = "P_Province";
            this.pProvinceDataGridViewTextBoxColumn.HeaderText = "P_Province";
            this.pProvinceDataGridViewTextBoxColumn.Name = "pProvinceDataGridViewTextBoxColumn";
            // 
            // wardIDDataGridViewTextBoxColumn
            // 
            this.wardIDDataGridViewTextBoxColumn.DataPropertyName = "Ward_ID";
            this.wardIDDataGridViewTextBoxColumn.HeaderText = "Ward_ID";
            this.wardIDDataGridViewTextBoxColumn.Name = "wardIDDataGridViewTextBoxColumn";
            // 
            // projectDataSet3
            // 
            this.projectDataSet3.DataSetName = "ProjectDataSet3";
            this.projectDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pINFOBindingSource2
            // 
            this.pINFOBindingSource2.DataMember = "P_INFO";
            this.pINFOBindingSource2.DataSource = this.projectDataSet3;
            // 
            // p_INFOTableAdapter2
            // 
            this.p_INFOTableAdapter2.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(357, 298);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "DELETE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(12, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(101, 27);
            this.button2.TabIndex = 24;
            this.button2.Text = "Go Back";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Delete_Patient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Name = "Delete_Patient";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pINFOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pINFOBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pINFOBindingSource2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private ProjectDataSet1 projectDataSet1;
        private System.Windows.Forms.BindingSource pINFOBindingSource;
        private ProjectDataSet1TableAdapters.P_INFOTableAdapter p_INFOTableAdapter;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private ProjectDataSet2 projectDataSet2;
        private System.Windows.Forms.BindingSource pINFOBindingSource1;
        private ProjectDataSet2TableAdapters.P_INFOTableAdapter p_INFOTableAdapter1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private ProjectDataSet3 projectDataSet3;
        private System.Windows.Forms.BindingSource pINFOBindingSource2;
        private ProjectDataSet3TableAdapters.P_INFOTableAdapter p_INFOTableAdapter2;
        private System.Windows.Forms.DataGridViewTextBoxColumn pIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pAGEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pConditionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pStatusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pProvinceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wardIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}