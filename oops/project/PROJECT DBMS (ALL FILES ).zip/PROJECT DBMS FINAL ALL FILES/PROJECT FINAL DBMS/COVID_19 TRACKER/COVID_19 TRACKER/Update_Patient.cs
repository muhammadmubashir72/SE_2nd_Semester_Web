﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace COVID_19_TRACKER
{

    public partial class Update_Patient : Form
    {
        public Update_Patient()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projectDataSet.STATUS_INFO' table. You can move, or remove it, as needed.
            this.sTATUS_INFOTableAdapter.Fill(this.projectDataSet.STATUS_INFO);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Project;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select dbo.CHECK_STATUS(@id,@status)", con);
            cmd.Parameters.AddWithValue("@id", textBox1.Text);
            cmd.Parameters.AddWithValue("@status", comboBox2.Text);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                var ch = dr.GetValue(0).ToString();
                if (ch == "F")
                {
                    MessageBox.Show("You cannot Update the Status of Dead patient");
                }
                
                else
                {
                    dr.Close();
                if (comboBox1.Text == "")
                {
                        comboBox1.Text = "EMPTY";
                }
                if (comboBox2.Text == "")
                {
                        comboBox2.Text = "EMPTY";
                }
                if (textBox1.Text == "")
                {
                    MessageBox.Show("You Must Provide an ID");
                }
                else
                {
                    SqlCommand UpdateComm = new SqlCommand("exec Update_Patient " + textBox1.Text + "," + comboBox1.Text + "," + comboBox2.Text, con);
                    var i = UpdateComm.ExecuteNonQuery();
                    if (i >=1)
                    {
                        MessageBox.Show("RECORD UPDATED");
                    }
                    else
                    {
                        MessageBox.Show("ERROR...!");
                    }
                    DataTable tab = new DataTable();
                    SqlCommand Q = new SqlCommand("select * from STATUS_INFO", con);
                    SqlDataAdapter tab1 = new SqlDataAdapter(Q);
                    tab1.Fill(tab);
                    dataGridView1.DataSource = tab;
                }
                }
            }
            textBox1.Text = "";
            comboBox1.Text = "";
            comboBox2.Text = "";
            con.Close();
            this.sTATUS_INFOTableAdapter.Fill(this.projectDataSet.STATUS_INFO);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home f1 = new Home();
            f1.ShowDialog();
        }
    }
}
