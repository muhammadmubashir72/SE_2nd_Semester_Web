﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace COVID_19_TRACKER
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }
         SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Project;Integrated Security=True");
        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Project;Integrated Security=True");
            SqlCommand Active = new SqlCommand("select count(*) from Alive", con);
            SqlCommand Recovered = new SqlCommand("select count(*) from Recovered", con);
            SqlCommand DEAD = new SqlCommand("select count(*) from Dead", con);
            SqlCommand Critical = new SqlCommand("select count(*) from Critical_Patient", con);
            con.Open();
            SqlDataReader DR1 = Active.ExecuteReader();
            if (DR1.Read())
            {
                textBox1.Text = DR1.GetValue(0).ToString();
            }
            DR1.Close();
            SqlDataReader DR2 = Recovered.ExecuteReader();
            if (DR2.Read())
            {
                textBox2.Text = DR2.GetValue(0).ToString();
            }
            DR2.Close();
            SqlDataReader DR3 = DEAD.ExecuteReader();
            if (DR3.Read())
            {
                textBox3.Text = DR3.GetValue(0).ToString();
            }
            DR3.Close();
            SqlDataReader DR4 = Critical.ExecuteReader();
            if (DR4.Read())
            {
                textBox4.Text = DR4.GetValue(0).ToString();
            }
            con.Close();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (comboBox1.Text != "OVER ALL") {
                SqlCommand Alive = new SqlCommand("select count(*) from Alive where P_province='" + comboBox1.Text+"'", con);
                SqlCommand DEAD = new SqlCommand("select count(*) from Dead where P_province='" + comboBox1.Text + "'", con);
                SqlCommand Critical = new SqlCommand("select count(*) from Critical_Patient where P_province='" + comboBox1.Text + "'", con);
                SqlCommand Recovered = new SqlCommand("select count(*) from Recovered where P_province='" + comboBox1.Text + "'", con);
                con.Open();

                SqlDataReader DRP = Alive.ExecuteReader();
                if (DRP.Read())
                {
                    textBox1.Text = DRP.GetValue(0).ToString();
                }
                DRP.Close();
                SqlDataReader DR2 = Recovered.ExecuteReader();
                if (DR2.Read())
                {
                    textBox2.Text = DR2.GetValue(0).ToString();
                }
                DR2.Close();
                SqlDataReader DR3 = DEAD.ExecuteReader();
                if (DR3.Read())
                {
                    textBox3.Text = DR3.GetValue(0).ToString();
                }
                DR3.Close();
                SqlDataReader DR4 = Critical.ExecuteReader();
                if (DR4.Read())
                {
                    textBox4.Text = DR4.GetValue(0).ToString();
                }
                DR4.Close();
                con.Close();
            }
            else
            {
                SqlCommand Active = new SqlCommand("select count(*) from Alive", con);
                SqlCommand Recovered = new SqlCommand("select count(*) from Recovered", con);
                SqlCommand DEAD = new SqlCommand("select count(*) from Dead", con);
                SqlCommand Critical = new SqlCommand("select count(*) from Critical_Patient", con);
                con.Open();
                SqlDataReader DR1 = Active.ExecuteReader();
                if (DR1.Read())
                {
                    textBox1.Text = DR1.GetValue(0).ToString();
                }
                DR1.Close();
                SqlDataReader DR2 = Recovered.ExecuteReader();
                if (DR2.Read())
                {
                    textBox2.Text = DR2.GetValue(0).ToString();
                }
                DR2.Close();
                SqlDataReader DR3 = DEAD.ExecuteReader();
                if (DR3.Read())
                {
                    textBox3.Text = DR3.GetValue(0).ToString();
                }
                DR3.Close();
                SqlDataReader DR4 = Critical.ExecuteReader();
                if (DR4.Read())
                {
                    textBox4.Text = DR4.GetValue(0).ToString();
                }
                con.Close();
            }
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Add_Patient f2 = new Add_Patient();
            f2.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Update_Patient f3 = new Update_Patient();
            f3.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete_Patient f4 = new Delete_Patient();
            f4.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            History H = new History();
            H.ShowDialog();
        }
    }
}
