﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace COVID_19_TRACKER
{
    public partial class Add_Patient : Form
    {
        public Add_Patient()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Project;Integrated Security=True");
            con.Open();
                SqlCommand Insert = new SqlCommand("exec Add_patient " + textBox2.Text + "," + textBox3.Text + "," + textBox4.Text + "," + comboBox1.Text + "," + textBox6.Text + "," + textBox7.Text + "," + comboBox2.Text + "," + comboBox3.Text + "," + comboBox5.Text + "," + comboBox4.Text, con);
                var i = Insert.ExecuteNonQuery();
                if (i >= 1)
                {
                    MessageBox.Show("RECORD ADDED");
                }
                else
                {
                    MessageBox.Show("ERROR...!");
                }
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                comboBox1.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";
                comboBox2.Text = "";
                comboBox3.Text = "";
                comboBox4.Text = "";
                comboBox5.Text = "";


                con.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home f1 = new Home();
            f1.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
