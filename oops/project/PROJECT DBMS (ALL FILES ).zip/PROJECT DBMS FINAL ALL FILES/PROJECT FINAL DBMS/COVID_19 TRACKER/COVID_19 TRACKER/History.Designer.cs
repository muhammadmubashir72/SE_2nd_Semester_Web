﻿namespace COVID_19_TRACKER
{
    partial class History
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.showHistoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.projectDataSet4 = new COVID_19_TRACKER.ProjectDataSet4();
            this.show_HistoryTableAdapter = new COVID_19_TRACKER.ProjectDataSet4TableAdapters.Show_HistoryTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.projectDataSet5 = new COVID_19_TRACKER.ProjectDataSet5();
            this.rPDayBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rP_DayTableAdapter = new COVID_19_TRACKER.ProjectDataSet5TableAdapters.RP_DayTableAdapter();
            this.projectDataSet6 = new COVID_19_TRACKER.ProjectDataSet6();
            this.showHistoryBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.show_HistoryTableAdapter1 = new COVID_19_TRACKER.ProjectDataSet6TableAdapters.Show_HistoryTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.provinceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.deleteDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.updateDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.admitDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.showHistoryBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.projectDataSet7 = new COVID_19_TRACKER.ProjectDataSet7();
            this.show_HistoryTableAdapter2 = new COVID_19_TRACKER.ProjectDataSet7TableAdapters.Show_HistoryTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.showHistoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rPDayBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.showHistoryBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.showHistoryBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet7)).BeginInit();
            this.SuspendLayout();
            // 
            // showHistoryBindingSource
            // 
            this.showHistoryBindingSource.DataMember = "Show_History";
            this.showHistoryBindingSource.DataSource = this.projectDataSet4;
            // 
            // projectDataSet4
            // 
            this.projectDataSet4.DataSetName = "ProjectDataSet4";
            this.projectDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // show_HistoryTableAdapter
            // 
            this.show_HistoryTableAdapter.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(300, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 42);
            this.label1.TabIndex = 1;
            this.label1.Text = "HISTORY";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(97, 29);
            this.button1.TabIndex = 2;
            this.button1.Text = "Goto Home";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // projectDataSet5
            // 
            this.projectDataSet5.DataSetName = "ProjectDataSet5";
            this.projectDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // rPDayBindingSource
            // 
            this.rPDayBindingSource.DataMember = "RP_Day";
            this.rPDayBindingSource.DataSource = this.projectDataSet5;
            // 
            // rP_DayTableAdapter
            // 
            this.rP_DayTableAdapter.ClearBeforeFill = true;
            // 
            // projectDataSet6
            // 
            this.projectDataSet6.DataSetName = "ProjectDataSet6";
            this.projectDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // showHistoryBindingSource1
            // 
            this.showHistoryBindingSource1.DataMember = "Show_History";
            this.showHistoryBindingSource1.DataSource = this.projectDataSet6;
            // 
            // show_HistoryTableAdapter1
            // 
            this.show_HistoryTableAdapter1.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn,
            this.ageDataGridViewTextBoxColumn,
            this.contactDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn,
            this.provinceDataGridViewTextBoxColumn,
            this.deleteDateDataGridViewTextBoxColumn,
            this.updateDateDataGridViewTextBoxColumn,
            this.admitDateDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.showHistoryBindingSource2;
            this.dataGridView1.Location = new System.Drawing.Point(24, 103);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(841, 242);
            this.dataGridView1.TabIndex = 3;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // ageDataGridViewTextBoxColumn
            // 
            this.ageDataGridViewTextBoxColumn.DataPropertyName = "Age";
            this.ageDataGridViewTextBoxColumn.HeaderText = "Age";
            this.ageDataGridViewTextBoxColumn.Name = "ageDataGridViewTextBoxColumn";
            // 
            // contactDataGridViewTextBoxColumn
            // 
            this.contactDataGridViewTextBoxColumn.DataPropertyName = "Contact";
            this.contactDataGridViewTextBoxColumn.HeaderText = "Contact";
            this.contactDataGridViewTextBoxColumn.Name = "contactDataGridViewTextBoxColumn";
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            // 
            // provinceDataGridViewTextBoxColumn
            // 
            this.provinceDataGridViewTextBoxColumn.DataPropertyName = "province";
            this.provinceDataGridViewTextBoxColumn.HeaderText = "province";
            this.provinceDataGridViewTextBoxColumn.Name = "provinceDataGridViewTextBoxColumn";
            // 
            // deleteDateDataGridViewTextBoxColumn
            // 
            this.deleteDateDataGridViewTextBoxColumn.DataPropertyName = "Delete_Date";
            this.deleteDateDataGridViewTextBoxColumn.HeaderText = "Delete_Date";
            this.deleteDateDataGridViewTextBoxColumn.Name = "deleteDateDataGridViewTextBoxColumn";
            // 
            // updateDateDataGridViewTextBoxColumn
            // 
            this.updateDateDataGridViewTextBoxColumn.DataPropertyName = "Update_Date";
            this.updateDateDataGridViewTextBoxColumn.HeaderText = "Update_Date";
            this.updateDateDataGridViewTextBoxColumn.Name = "updateDateDataGridViewTextBoxColumn";
            // 
            // admitDateDataGridViewTextBoxColumn
            // 
            this.admitDateDataGridViewTextBoxColumn.DataPropertyName = "Admit_Date";
            this.admitDateDataGridViewTextBoxColumn.HeaderText = "Admit_Date";
            this.admitDateDataGridViewTextBoxColumn.Name = "admitDateDataGridViewTextBoxColumn";
            // 
            // showHistoryBindingSource2
            // 
            this.showHistoryBindingSource2.DataMember = "Show_History";
            this.showHistoryBindingSource2.DataSource = this.projectDataSet7;
            // 
            // projectDataSet7
            // 
            this.projectDataSet7.DataSetName = "ProjectDataSet7";
            this.projectDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // show_HistoryTableAdapter2
            // 
            this.show_HistoryTableAdapter2.ClearBeforeFill = true;
            // 
            // History
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(889, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Name = "History";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.History_Load);
            ((System.ComponentModel.ISupportInitialize)(this.showHistoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rPDayBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.showHistoryBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.showHistoryBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private ProjectDataSet4 projectDataSet4;
        private System.Windows.Forms.BindingSource showHistoryBindingSource;
        private ProjectDataSet4TableAdapters.Show_HistoryTableAdapter show_HistoryTableAdapter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private ProjectDataSet5 projectDataSet5;
        private System.Windows.Forms.BindingSource rPDayBindingSource;
        private ProjectDataSet5TableAdapters.RP_DayTableAdapter rP_DayTableAdapter;
        private ProjectDataSet6 projectDataSet6;
        private System.Windows.Forms.BindingSource showHistoryBindingSource1;
        private ProjectDataSet6TableAdapters.Show_HistoryTableAdapter show_HistoryTableAdapter1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private ProjectDataSet7 projectDataSet7;
        private System.Windows.Forms.BindingSource showHistoryBindingSource2;
        private ProjectDataSet7TableAdapters.Show_HistoryTableAdapter show_HistoryTableAdapter2;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ageDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn provinceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn deleteDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn updateDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn admitDateDataGridViewTextBoxColumn;
    }
}